
let divs = document.querySelectorAll(".Container");

let texts = ["First Div", "Second Div", "Third Div"];

for (let i = 0; i < divs.length; i++) {
    divs[i].textContent = texts[i];
}
